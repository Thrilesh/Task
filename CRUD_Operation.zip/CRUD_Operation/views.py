from rest_framework import viewsets
from CRUD_Operation.models import Book
from CRUD_Operation.serializers import BookSerializer

class BookViewSet(viewsets.ModelViewSet):
    queryset = Book.objects.all()
    serializer_class = BookSerializer
